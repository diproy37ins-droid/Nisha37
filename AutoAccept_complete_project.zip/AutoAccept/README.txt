1. Android Studio -> File > Open -> AutoAccept ফোল্ডার বাছুন
2. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন (ইন্টারনেট লাগবে)
3. Build > Build Bundle(s) / APK(s) > Build APK(s)
4. APK: app/build/outputs/apk/debug/app-debug.apk
5. ফোনে install করে অ্যাপ খুলুন, তিনটা permission বাটন দিয়ে permission দিন
