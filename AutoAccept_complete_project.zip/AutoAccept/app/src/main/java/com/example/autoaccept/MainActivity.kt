package com.example.autoaccept

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private lateinit var countView: TextView
    private lateinit var enableSwitch: Switch
    private lateinit var accStatus: TextView
    private lateinit var ovStatus: TextView
    private lateinit var batStatus: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
        }

        fun sw(label: String, key: String, def: Boolean) = Switch(this).apply {
            text = label
            isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply() }
        }
        enableSwitch = sw("Auto Accept চালু", "enabled", true)
        val floatSwitch = sw("ফ্লোটিং ON/OFF বাটন দেখান", "floating", true)
        val vibSwitch = sw("Accept হলে ভাইব্রেট", "vibrate", true)

        fun numInput(hint: String, key: String) = EditText(this).apply {
            this.hint = hint
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            val s = prefs.getFloat(key, 0f)
            if (s > 0f) setText(s.toString())
        }
        fun hourInput(hint: String, key: String) = EditText(this).apply {
            this.hint = hint
            inputType = InputType.TYPE_CLASS_NUMBER
            val s = prefs.getInt(key, -1)
            if (s >= 0) setText(s.toString())
        }
        val fareInput = numInput("সর্বনিম্ন ভাড়া (₹), 0 = বন্ধ", "minFare")
        val distInput = numInput("সর্বোচ্চ পিকআপ দূরত্ব (km), 0 = বন্ধ", "maxPickupKm")
        val startInput = hourInput("শুরুর ঘণ্টা (0-23), ফাঁকা = বন্ধ", "startHour")
        val endInput = hourInput("শেষের ঘণ্টা (0-23)", "endHour")

        val typeLabel = TextView(this).apply { text = "রাইডের ধরন (কিছু না বাছলে সব):"; setPadding(0, 24, 0, 0) }
        fun cb(label: String, key: String) = CheckBox(this).apply {
            text = label
            isChecked = prefs.getBoolean(key, false)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply() }
        }
        val bike = cb("Bike", "type_bike"); val auto = cb("Auto", "type_auto"); val cab = cb("Cab", "type_cab")

        val save = Button(this).apply {
            text = "Save"
            setOnClickListener {
                prefs.edit()
                    .putFloat("minFare", fareInput.text.toString().toFloatOrNull() ?: 0f)
                    .putFloat("maxPickupKm", distInput.text.toString().toFloatOrNull() ?: 0f)
                    .putInt("startHour", startInput.text.toString().toIntOrNull()?.coerceIn(0, 23) ?: -1)
                    .putInt("endHour", endInput.text.toString().toIntOrNull()?.coerceIn(0, 23) ?: -1)
                    .apply()
                Toast.makeText(context, "সেভ হয়েছে", Toast.LENGTH_SHORT).show()
            }
        }
        countView = TextView(this).apply { textSize = 16f; setPadding(0, 24, 0, 24) }
        val reset = Button(this).apply {
            text = "কাউন্টার রিসেট"
            setOnClickListener { prefs.edit().putInt("count", 0).apply(); refresh() }
        }
        accStatus = TextView(this).apply { setPadding(0, 24, 0, 0) }
        ovStatus = TextView(this).apply { setPadding(0, 24, 0, 0) }
        batStatus = TextView(this).apply { setPadding(0, 24, 0, 0) }
        val access = Button(this).apply {
            text = "Accessibility permission"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val overlay = Button(this).apply {
            text = "Overlay permission"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        val battery = Button(this).apply {
            text = "Battery permission (Unrestricted)"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            }
        }
        listOf(enableSwitch, floatSwitch, vibSwitch, fareInput, distInput, startInput, endInput,
            typeLabel, bike, auto, cab, save, countView, reset,
            accStatus, access, ovStatus, overlay, batStatus, battery).forEach { layout.addView(it) }
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    override fun onResume() {
        super.onResume()
        enableSwitch.isChecked = getSharedPreferences("cfg", MODE_PRIVATE).getBoolean("enabled", true)
        refresh()
    }

    private fun refresh() {
        val c = getSharedPreferences("cfg", MODE_PRIVATE).getInt("count", 0)
        countView.text = "মোট accept করা রাইড: $c"

        val enabledServices = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        val accOk = enabledServices.contains("$packageName/", true)
        val ovOk = Settings.canDrawOverlays(this)
        val batOk = (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        accStatus.text = "Accessibility: " + if (accOk) "✅ চালু" else "❌ বন্ধ"
        ovStatus.text = "Overlay: " + if (ovOk) "✅ চালু" else "❌ বন্ধ"
        batStatus.text = "Battery: " + if (batOk) "✅ Unrestricted" else "❌ Restricted"
    }
}
