package com.example.autoaccept

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import java.util.Calendar

class AutoAcceptService : AccessibilityService() {
    private var lastClick = 0L
    private val fareRegex = Regex("(?:₹|Rs\\.?|INR)\\s*([0-9]+(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE)
    private val kmRegex = Regex("([0-9]+(?:\\.[0-9]+)?)\\s*km", RegexOption.IGNORE_CASE)
    private val mRegex = Regex("([0-9]+)\\s*m\\b", RegexOption.IGNORE_CASE)

    private lateinit var prefs: SharedPreferences
    private var wm: WindowManager? = null
    private var floatBtn: TextView? = null
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "enabled" || key == "floating") updateFloat()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        updateFloat()
    }

    override fun onDestroy() {
        if (::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        removeFloat()
        super.onDestroy()
    }

    // ---------- ফ্লোটিং on/off বাটন ----------
    private fun updateFloat() {
        if (!prefs.getBoolean("floating", true)) { removeFloat(); return }
        if (floatBtn == null) createFloat()
        val on = prefs.getBoolean("enabled", true)
        floatBtn?.apply {
            text = if (on) "ON" else "OFF"
            (background as? GradientDrawable)?.setColor(if (on) Color.parseColor("#2E7D32") else Color.parseColor("#C62828"))
        }
    }

    private fun createFloat() {
        val tv = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(36, 28, 36, 28)
            background = GradientDrawable().apply { cornerRadius = 80f }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 300 }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        tv.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { sx = ev.rawX; sy = ev.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - sx).toInt(); val dy = (ev.rawY - sy).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    if (moved) { lp.x = ox + dx; lp.y = oy + dy; wm?.updateViewLayout(tv, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    prefs.edit().putBoolean("enabled", !prefs.getBoolean("enabled", true)).apply()
                }
            }
            true
        }
        wm?.addView(tv, lp)
        floatBtn = tv
    }

    private fun removeFloat() {
        floatBtn?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        floatBtn = null
    }

    // ---------- সময়সূচি ----------
    private fun inSchedule(): Boolean {
        val s = prefs.getInt("startHour", -1); val e = prefs.getInt("endHour", -1)
        if (s < 0 || e < 0 || s == e) return true
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (s < e) h in s until e else (h >= s || h < e)
    }

    // ---------- মূল কাজ ----------
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || !::prefs.isInitialized) return
        if (e.packageName?.toString()?.contains("rapido", true) != true) return
        if (!prefs.getBoolean("enabled", true)) return
        if (!inSchedule()) return

        val now = System.currentTimeMillis()
        if (now - lastClick < 800) return
        val root = rootInActiveWindow ?: return
        val buttons = root.findAccessibilityNodeInfosByText("Accept")
        if (buttons.isEmpty()) return

        val texts = ArrayList<String>()
        collect(root, texts)

        // রাইডের ধরন ফিল্টার
        val types = listOf("bike", "auto", "cab").filter { prefs.getBoolean("type_$it", false) }
        if (types.isNotEmpty()) {
            val all = texts.joinToString(" ").lowercase()
            if (types.none { all.contains(it) }) return
        }

        // ভাড়া ফিল্টার
        val minFare = prefs.getFloat("minFare", 0f)
        if (minFare > 0f) {
            val fare = texts.flatMap { t -> fareRegex.findAll(t).mapNotNull { it.groupValues[1].toFloatOrNull() } }.maxOrNull() ?: return
            if (fare < minFare) return
        }

        // পিকআপ দূরত্ব ফিল্টার
        val maxKm = prefs.getFloat("maxPickupKm", 0f)
        if (maxKm > 0f) {
            val dists = ArrayList<Float>()
            texts.forEach { t ->
                kmRegex.findAll(t).forEach { m -> m.groupValues[1].toFloatOrNull()?.let { dists.add(it) } }
                mRegex.findAll(t).forEach { m -> m.groupValues[1].toFloatOrNull()?.let { dists.add(it / 1000f) } }
            }
            val pickup = dists.minOrNull() ?: return
            if (pickup > maxKm) return
        }

        for (n in buttons) {
            var t: AccessibilityNodeInfo? = n
            while (t != null && !t.isClickable) t = t.parent
            if (t != null && t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                lastClick = now
                prefs.edit().putInt("count", prefs.getInt("count", 0) + 1).apply()
                if (prefs.getBoolean("vibrate", true)) vibrate()
                break
            }
        }
    }

    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<String>) {
        if (node == null) return
        node.text?.toString()?.let { out.add(it) }
        node.contentDescription?.toString()?.let { out.add(it) }
        for (i in 0 until node.childCount) collect(node.getChild(i), out)
    }

    private fun vibrate() {
        val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
        v.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    override fun onInterrupt() {}
}
